# 📦 Import Required Libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings

# Load Dataset
df = pd.read_csv(r"C:\Users\udays\OneDrive\Desktop\CSV\netflix_content_2023.csv")

# Display first few rows
print("First 5 rows:\n", df.head())

# Basic overview
print("Shape of the dataset:", df.shape)
print("\nColumn names:\n", df.columns)
print("\nData types:\n", df.dtypes)
print("\nMissing values:\n", df.isnull().sum())

# Summary statistics for numeric columns
print("\nSummary statistics:\n", df.describe(include='all'))

# Check for duplicates
print("\nNumber of duplicate rows:", df.duplicated().sum())

# Drop duplicates if any
df.drop_duplicates(inplace=True)
print("\nNumber of duplicate rows After Dropping Duplicates:", df.duplicated().sum())

# Suppress warnings
warnings.filterwarnings("ignore")

# Set style and font
sns.set(style="whitegrid")
plt.rcParams['figure.figsize'] = (8, 6)
plt.rcParams['font.family'] = 'Arial'


# Data Cleaning

# Convert 'Hours Viewed' to numeric (remove commas)
df['Hours Viewed'] = df['Hours Viewed'].str.replace(',', '', regex=True).astype(float)

# Convert 'Release Date' to datetime format
df['Release Date'] = pd.to_datetime(df['Release Date'], errors='coerce')

# Fill missing release dates with NaT (standard for missing datetime)
df['Release Date'] = df['Release Date'].fillna(pd.NaT)

# Extract Month from Release Date
df['Month'] = df['Release Date'].dt.month_name()


#Objective 1: Top 10 Most Viewed Titles

top_10 = df.sort_values('Hours Viewed', ascending=False).head(10)

plt.figure()
sns.barplot(data=top_10, x='Hours Viewed', y='Title', palette='Blues_r', hue='Title', legend=False)
plt.title("Top 10 Most Viewed Netflix Titles (2023)")
plt.xlabel("Hours Viewed")
plt.ylabel("Title")
plt.tight_layout()
plt.show()


# Objective 2: Movies vs Shows

plt.figure()
sns.countplot(data=df, x='Content Type', palette='pastel', hue='Content Type', legend=False)
plt.title("Distribution of Movies vs Shows on Netflix (2023)")
plt.xlabel("Content Type")
plt.ylabel("Count")
plt.tight_layout()
plt.show()


# Objective 3: Top 10 Languages by Hours Viewed

lang_view = df.groupby('Language Indicator')['Hours Viewed'].sum().sort_values(ascending=False).head(10)

plt.figure()
lang_view.plot(kind='barh', color='skyblue')
plt.title("Top 10 Languages by Total Hours Viewed")
plt.xlabel("Total Hours Viewed")
plt.gca().invert_yaxis()
plt.tight_layout()
plt.show()


# Objective 4: Monthly Release Timeline

# Filter out rows where Month is NaN (due to missing Release Date)
df_time = df.dropna(subset=['Month'])

month_order = ['January', 'February', 'March', 'April', 'May', 'June',
               'July', 'August', 'September', 'October', 'November', 'December']

monthly_release = df_time['Month'].value_counts().reindex(month_order)

plt.figure()
monthly_release.plot(kind='bar', color='coral')
plt.title("Number of Titles Released Each Month (2023)")
plt.xlabel("Month")
plt.ylabel("Number of Titles")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# Objective 5: Global Availability

global_counts = df['Available Globally?'].value_counts()

plt.figure()
global_counts.plot(kind='pie', autopct='%1.1f%%', startangle=90, colors=['lightgreen', 'lightgrey'])
plt.title("Global Availability of Netflix Titles")
plt.ylabel("")
plt.tight_layout()
plt.show()




#Objective 6: Title Length vs. Hours Viewed
#Analyzes whether short or long titles perform better
df['Title Length'] = df['Title'].apply(lambda x: len(str(x)))
plt.figure()
sns.scatterplot(data=df, x='Title Length', y='Hours Viewed', alpha=0.6)
plt.title("Title Length vs. Hours Viewed")
plt.xlabel("Title Length (characters)")
plt.ylabel("Hours Viewed")
plt.tight_layout()
plt.show()



#Objective 7: Distribution of Hours Viewed
plt.figure()
sns.histplot(df['Hours Viewed'], bins=30, kde=True, color='purple')
plt.title("Distribution of Hours Viewed")
plt.xlabel("Hours Viewed")
plt.ylabel("Number of Titles")
plt.tight_layout()
plt.show()


#Objective 8: Language-wise Content Count
lang_count = df['Language Indicator'].value_counts().head(10)
plt.figure()
sns.barplot(x=lang_count.values, y=lang_count.index, palette='Set2')
plt.title("Top 10 Languages by Number of Titles")
plt.xlabel("Number of Titles")
plt.ylabel("Language")
plt.tight_layout()
plt.show()




